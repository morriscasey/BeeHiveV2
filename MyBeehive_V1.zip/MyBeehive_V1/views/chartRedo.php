<?php
include '../header.php';
include 'php/dbcon.php';
$conn=read();

?>
<html>
<head>
    <title>BeeHive Mite Chart</title>
</head>
<body>
<?php
        
$statement = $conn->prepare("SELECT SUM(num_mites) as mitecount,  MONTH(collection_date) AS month FROM samples WHERE YEAR(collection_date) = 2016 GROUP BY MONTH(collection_date)");
            // References namespace of dog to query
        
$statement->execute();
            
//fetch data
while ($row = mysql_fetch_array($result)) {
    $entry .= "['".$row{'date'}."',".$row{'weight'}."],";
}
//close the connection
mysql_close($dbhandle);
?>

<div id="chart_div" style="width: 100%; height: 500px;"></div>

<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<script type="text/javascript">
    google.load("visualization", "1", {packages:["corechart"]});
    google.setOnLoadCallback(drawChart);
    function drawChart() {
        var data = google.visualization.arrayToDataTable([
        ['Date',    'Weight'],
        <?php echo $entry ?>
    ]);
        var options = {
            title: 'Weight Tracker',
            curveType: 'function',
            legend: { position: 'bottom' }
        };
        var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
        chart.draw(data, options);
    }
</script>
</body>
</html>