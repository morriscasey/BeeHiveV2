<?php


echo "Data Recorded Successfully!";
include "hivelist.php";

?>