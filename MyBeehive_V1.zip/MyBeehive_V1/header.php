<!DOCTYPE html>

<html lang='en'>
	<head>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="author" content="Melissa Curry" />
		<meta name="description" content="Web Application to help Green River Honeybees track mites. Users can submit their mite observations, which will provide Daniel Najera with data he can use." />
		<meta name="keywords" content="GRC, Green River College, Green River Honeybees, honebees, mites, hive infestations, save the bees" />
	
		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
		<!-- jQuery library -->
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

		<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.13.0/moment.js"></script>

		<!-- Latest compiled JavaScript -->
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

		<script src='https://www.google.com/recaptcha/api.js'></script>
		<!--font awesome-->
		<script src="https://use.fontawesome.com/93c8ead996.js"></script>

		<link href='https://fonts.googleapis.com/css?family=Shadows+Into+Light+Two' rel='stylesheet' type='text/css'>