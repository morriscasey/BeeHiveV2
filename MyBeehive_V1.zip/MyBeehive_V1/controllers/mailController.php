<?php
/**
* mailController is used when user selects the mail icon in footer, and the actions are handled as shown in cases below
*/

session_start();
include('models/mailModel.php');




$_SESSION['email'] = $_POST['email'];
$_SESSION['subject'] = $_POST['subject'];
$_SESSION['body'] = $_POST['body'];
$_SESSION['name'] = $_POST['name'];

if(isset($_GET['action'])){
	$action = $_GET['action'];
}

/*create new MailModel object with a connection to db*/
$db = new mailModel();
$db->connect();
//help pass samples to various switches


switch($action){


	/*if action is mail, then the mailForm will be displayed*/
	case "mail":

   		include'views/mailForm.php';
   		break;
   	/*if action is send, then the email will be processed and sent to admin, then confimation page dispayed*/
	case "send":
		// My email address

      $recipient = 'dnajera@greenriver.edu';
      $email = $_SESSION['email'];
	  $subject = $_SESSION['subject'];
	  $body = $_SESSION['body'];
	  $name = $_SESSION['name'];
   
   		$mail = $db->sendMail($email, $subject, $body, $name);
   		include'views/confirmMail.php';
   		break;


		default:
			include('views/hiveForm.php');
			break;


}






   

 ?>