<?php
/*Used to begin a connectino with the TODO: modify files to be class es of thier own th that would act as the BaseModel*/
function read(){
$servername = "localhost";
$username = "beehive";
$password = "e;zKdn95R(yi";
$dbname = "beehive_mite_database";


try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $conn;
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
}

function writeDatabase($data){
$servername = "localhost";
$username = "beehive";
$password = "e;zKdn95R(yi";
$dbname = "beehive_mite_database";


try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    return $conn;
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }
}


function selectData($currentYear){
    $stmt = $conn->prepare("SELECT MONTH(collection_date) AS month, DAY(collection_date) AS day, COUNT(*) AS count FROM samples WHERE YEAR(collection_date) = '2016' GROUP BY DAY(collection_date)");

     // $stmt = $conn->prepare("SELECT hive_id, num_mites, collection_date FROM samples");
      $stmt->execute();
}




 /* function miteCount($year){

            
            $statement = $this->connection->prepare("SELECT SUM(num_mites) as mitecount, MONTH(collection_date) as month FROM samples WHERE YEAR(collection_date) = :year GROUP BY MONTH(collection_date)");
            // References namespace of dog to query
            $statement->bindParam(':year', $year, PDO::PARAM_INT);
            $statement->execute();
            $data = array();
            $while($row = $statement->fetchAll()){
              $data[] =$row;
            }
            // Returns selected rows
          /*  $row = $statement->fetchAll();
    
            return $row;*/

         /*   return $data;
  
    }*/

?>
