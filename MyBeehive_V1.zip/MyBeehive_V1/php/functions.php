<?php
require "dbcon.php";

$conn = writeDatabase();

public function selectData(){
	
	 $stmt = $conn->prepare("SELECT MONTH(collection_date) AS month, DAY(collection_date) AS day, COUNT(*) AS count FROM samples WHERE YEAR(collection_date) = '2016' GROUP BY DAY(collection_date)");

     // $stmt = $conn->prepare("SELECT hive_id, num_mites, collection_date FROM samples");
      $stmt->execute();
}