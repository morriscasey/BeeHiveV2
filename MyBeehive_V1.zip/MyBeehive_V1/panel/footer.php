<?php
$_SESSION['action'] = $_GET['action'];
$_SESSION['controller'] = $_GET['controller'];
?>
<!-- footer content -->
<div class = "footer">
<!--Brand Logo -->

		<div class="row col-md-12 col-sm-12 text-center fblock">
			
			<a href="http://greenriver.edu/"><img class="fbrand" src="assets/img/GR-logo-Wht.png"></a></li>
			
			<ul class="list-inline">
				<li class ="icons"><a class="icons"href="?controller=mail&action=mail"><i class="fa fa-envelope-o fa-4x" aria-hidden="true"></i></a></li>
				<li class="icons"><a class="icons" href="https://www.facebook.com/GreenRiverHoneybees/?fref=ts" target="_blank" ><i class="fa fa-facebook-square fa-4x"></i></a>
			</ul>
			<h5><strong>Green River Honeybees &copy 2016</strong></h5>
		</div>
		
		<!--End of Brand Logo -->
   <!-- <div class="pull-right">
       <strong> Green River Honeybess &copy 2016</strong>
    </div>-->
    <div class="clearfix"></div>
</div>
<!-- /footer content -->


