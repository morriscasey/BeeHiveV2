google.charts.load('current', {packages: ['corechart', 'line']});
  google.charts.setOnLoadCallback(drawBackgroundColor);
  
  function drawBackgroundColor() {
      var data = new google.visualization.DataTable();
      data.addColumn('number', 'X');
      data.addColumn('number', 'Mites Reported');

      data.addRows([
        [0, 0],   [1, 10],  [2, 23],  [3, 17],  [4, 18],  [5, 9],
        [6, 11],  [7, 27],  [8, 33],  [9, 40],  [10, 32], [11, 35], [12, 5]
      ]);

      var options = {
        hAxis: {
            title: 'Month',
            showTextEvery: 1,
            ticks: [{
                v: 0,
                f: 'Jan'
            }, {
                v: 1,
                f: 'Feb'
            }, {
                v: 2,
                f: 'Mar'
            }, {
                v: 3,
                f: 'Apr'
            }, {
                v: 4,
                f: 'May'
            }, {
                v: 5,
                f: 'Jun'
            }, {
                v: 6,
                f: 'Jul'
            }, {
                v: 7,
                f: 'Aug'
            }, {
                v: 8,
                f: 'Sep'
            }, {
                v: 9,
                f: 'Oct'
            }, {
                v: 10,
                f: 'Nov'
            }, {
                v: 11,
                f: 'Dec'
            }]
        }
    };
      var chart = new google.visualization.LineChart(document.getElementById('chart_div'));
      chart.draw(data, options);
    }
    
  </script>
  <div id="testchart"></div>
