<?php
//start a session
session_start();

require('../header.php');


    //if not logged in as admin, send to login page
    if(!isset($_SESSION['username'])){
        header("Location: adminlogin.php");
    }

?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/t/dt/dt-1.10.11/datatables.min.css"/>
<link rel="stylesheet" type="text/css" href="../assets/databaseCss.css"/>
<script type="text/javascript" src="https://cdn.datatables.net/t/dt/dt-1.10.11/datatables.min.js"></script>
<script type="text/javascript" language="javascript" src="js/jquery.dataTables.js"></script>


<script type="text/javascript" language="javascript" class="init">
        $(document).ready(function() {
            $('#bee').DataTable();
        } );

</script> 



<!--<table id="example" cellspacing="0" width="100%"> <thead>
<tr> <th>Hive ID</th> <th>Mites</th> <th>Mobile</th> <th>Start Date</th> </tr> </thead> </table> </body> -->

<div class="row">
<br>
<a href="../download.php"id='download' class="btn btn-primary"  role="button">Downloadd Excel File</a>



<h1 class="text-center">Observations:</h1>
    <br>
    <table id="bee" class="display" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Hive ID</th>
                <th>Collection Date</th>
                <th>Sample Period</th>
                <th>Mites</th>
                <th>Notes</th>
            </tr>
        </thead>
 
        <tfoot>
            <tr>
                <th>Hive ID</th>
                <th>Collection Date</th>
                <th>Sample Period</th>
                <th>Mites</th>
                <th>Notes</th>
            </tr>
        </tfoot>
 
        <tbody>
          <?php
            // Counter to keep track of multidimensional array
            $counter = 0;
            foreach($samples as $row){
                $hivename =$row['hive_id'];
                $miltaryDate=$row['observationdate'];
                $date = date('m/d/Y h:i a', strtotime($miltaryDate));
                $sample_period =$row['sample_period'];
                $mites =$row['num_mites'];
                $notes =$row['notes'];
                $counter++;
                echo "<tr><td>$hivename</td><td class='timeDate'>$date</td><td>$sample_period</td><td>$mites</td><td>$notes</td></tdtr>";
            };
           ?>
        </tbody>
    </table>
    <br>